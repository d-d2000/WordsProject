package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Getter
@Setter
@TableName("states_info")
@ApiModel(value = "StatesInfo对象", description = "")
public class StatesInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("预约状态表id")
    @TableId(value = "states_id", type = IdType.AUTO)
    private Integer statesId;

    @ApiModelProperty("商家id")
    @TableField("business_id")
    private Integer businessId;

    @ApiModelProperty("种类id")
    @TableField("kind_id")
    private Integer kindId;

    @ApiModelProperty("用户id")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty("状态id，0：等待拍摄，1：已拍摄，2：未评价，3已评价")
    @TableField("product_states")
    private Integer productStates;

    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @ApiModelProperty("下订单时间")
    @TableField("pay_time")
    private LocalDateTime payTime;


}
