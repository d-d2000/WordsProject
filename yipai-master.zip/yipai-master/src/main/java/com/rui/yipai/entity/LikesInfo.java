package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Getter
@Setter
@TableName("likes_info")
@ApiModel(value = "LikesInfo对象", description = "")
public class LikesInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("点赞表id")
    @TableId("like_id")
    private Integer likeId;

    @ApiModelProperty("动态id")
    @TableField("activity_id")
    private Integer activityId;

    @ApiModelProperty("点赞人的id拼接")
    @TableField("user_like")
    private String userLike;


}
