package com.rui.yipai.dao;

import com.rui.yipai.pojo.UserReplyVo;
import io.lettuce.core.dynamic.annotation.Param;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserReplyDaoMapper {
    @Select("select from_user_id,to_user_id,reply_id,comment_id,comment_msg,create_date from user_reply "
            +"where comment_id=#{comment_id} order by reply_id desc")
    @Results({
            @Result(property = "fromUserId", column = "from_user_id"),
            @Result(property = "toUserId", column = "to_user_id"),
            @Result(
                    property = "fromUserInfo", column = "from_user_id",
                    one = @One(select = "com.rui.yipai.dao.UserActivityDaoMapper.getNameAndFace")
            ),
            @Result(
                    property = "toUserInfo", column = "to_user_id",
                    one = @One(select = "com.rui.yipai.dao.UserActivityDaoMapper.getNameAndFace")
            )
    })
    List<UserReplyVo> getPage(@Param("comment_id") int commentId);
}
