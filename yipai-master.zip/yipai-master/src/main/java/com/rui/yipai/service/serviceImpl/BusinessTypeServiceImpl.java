package com.rui.yipai.service.serviceImpl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.rui.yipai.entity.BusinessInfo;
import com.rui.yipai.entity.BusinessType;
import com.rui.yipai.entity.UserInfo;
import com.rui.yipai.mapper.BusinessInfoMapper;
import com.rui.yipai.mapper.BusinessTypeMapper;
import com.rui.yipai.pojo.ServiceType;
import com.rui.yipai.service.BusinessTypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.rui.yipai.utils.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2023-01-12
 */
@Service
public class BusinessTypeServiceImpl extends ServiceImpl<BusinessTypeMapper, BusinessType> implements BusinessTypeService {

    @Autowired
    RedisTemplate redisTemplate;

    @Autowired
    BusinessInfoMapper businessInfoMapper;

    @Autowired
    BusinessTypeMapper businessTypeMapper;

    /**
     * 商家添加服务
     * @param list
     * @return
     */
    @Override
    public boolean addService(List<ServiceType> list) {

        //获取businessId
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        int userId = userInfo.getUserId();
        QueryWrapper<BusinessInfo> businessInfoQueryWrapper = new QueryWrapper<>();
        businessInfoQueryWrapper.select("business_id").eq("user_id",userId);
        BusinessInfo businessInfo = businessInfoMapper.selectOne(businessInfoQueryWrapper);
        //查询是否已经有过服务 否则只做更新
        BusinessType businessType = new BusinessType();

        QueryWrapper<BusinessType> wrapper = new QueryWrapper<>();
        wrapper.select("type_id","kind_pic").eq("business_id",businessInfo.getBusinessId());
        BusinessType businessType1 = businessTypeMapper.selectOne(wrapper);
        boolean res = null == businessType1 ? false : true;

        StringBuffer stringBuffer = new StringBuffer();

        for (ServiceType serviceType : list) {
            int code = serviceType.getTypeCode();
            switch(code) {
                case 1:businessType.setPortrait(code);break;
                case 2:businessType.setWedding(code);break;
                case 3:businessType.setCertificates(code);break;
                case 4:businessType.setGravida(code);break;
                case 5:businessType.setPhoto(code);break;
                case 7:businessType.setWeddingFollow(code);break;
                case 8:businessType.setProduct(code);break;
                case 9:businessType.setPets(code);break;
                case 10:businessType.setBaby(code);break;
            }
            //设置图片
            stringBuffer.append("::" + code + "::" + serviceType.getKindPic());
        }
        businessType.setKindPic(stringBuffer.toString());
        System.out.println(businessInfo.getBusinessId());
        int flag;
        //如果之前就有数据则更新 没有则插入
        if(res) {
            UpdateWrapper<BusinessType> updateWrapper = new UpdateWrapper<>();
            updateWrapper.eq("type_id",businessType1.getTypeId());
            businessType.setKindPic(businessType1.getKindPic() + stringBuffer.toString());
            flag =  businessTypeMapper.update(businessType,updateWrapper);
        } else {
            businessType.setBusinessId(businessInfo.getBusinessId());
            flag = businessTypeMapper.insert(businessType);
        }
        if(flag == 1) return true;
        return false;
    }

    /**
     * 商家查询有哪些服务
     * @param
     * @return
     */
    @Override
    public BusinessType myService() {
        //获取businessId
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        QueryWrapper<BusinessInfo> businessInfoQueryWrapper = new QueryWrapper<>();
        int userId = userInfo.getUserId();
        businessInfoQueryWrapper.select("business_id").eq("user_id",userId);
        BusinessInfo businessInfo = businessInfoMapper.selectOne(businessInfoQueryWrapper);

        QueryWrapper<BusinessType> wrapper = new QueryWrapper<>();
        wrapper.eq("business_id",businessInfo.getBusinessId());
        BusinessType businessType = businessTypeMapper.selectOne(wrapper);

        return businessType;
    }
}
