package com.rui.yipai.service.serviceImpl;

import com.rui.yipai.entity.UserReply;
import com.rui.yipai.mapper.UserReplyMapper;
import com.rui.yipai.service.UserReplyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Service
public class UserReplyServiceImpl extends ServiceImpl<UserReplyMapper, UserReply> implements UserReplyService {

}
