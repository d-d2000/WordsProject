package com.rui.yipai.dao;

import com.rui.yipai.entity.TypeDetail;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface StatesInfoDaoMapper {
    @Select("select * from type_detail where detail_id = (select detail_id from service_info where service_id = #{service_id})")
    TypeDetail getByServiceId(@Param("service_id") int service_id);
}
