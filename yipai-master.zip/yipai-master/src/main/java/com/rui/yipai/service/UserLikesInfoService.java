package com.rui.yipai.service;

import com.rui.yipai.entity.UserLikesInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yr
 * @since 2022-10-12
 */
public interface UserLikesInfoService extends IService<UserLikesInfo> {

}
