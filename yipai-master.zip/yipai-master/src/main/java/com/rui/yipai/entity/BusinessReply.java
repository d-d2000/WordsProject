package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Getter
@Setter
@TableName("business_reply")
@ApiModel(value = "BusinessReply对象", description = "")
public class BusinessReply implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("回复表的id")
    @TableId(value = "business_reply_id", type = IdType.AUTO)
    private Integer businessReplyId;

    @ApiModelProperty("当前一级评论的id")
    @TableField("bussiness_comment_id")
    private Integer bussinessCommentId;

    @ApiModelProperty("二级评论人的id")
    @TableField("from_user_id")
    private Integer fromUserId;

    @ApiModelProperty("回复谁的id")
    @TableField("to_user_id")
    private Integer toUserId;

    @ApiModelProperty("回复内容")
    @TableField("reply_msg")
    private String replyMsg;

    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @ApiModelProperty("日期")
    @TableField("create_date")
    private LocalDateTime createDate;


}
