package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Getter
@Setter
@TableName("type_detail")
@ToString
@ApiModel(value = "TypeDetail对象", description = "")
public class TypeDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("商家上传商品的默认id")
    @TableId(value = "detail_id", type = IdType.AUTO)
    private Integer detailId;

    @ApiModelProperty("商家id")
    @TableField("business_id")
    private Integer businessId;

    @ApiModelProperty("商品种类的id")
    @TableField("kind_id")
    private Integer kindId;

    @ApiModelProperty("商品封面")
    @TableField("first_pic")
    private String firstPic;

    @ApiModelProperty("商品描述")
    @TableField("describes")
    private String describes;

    @ApiModelProperty("样片的拼接")
    @TableField("sample_list")
    private String sampleList;

    @ApiModelProperty("商品状态")
    @TableField("product_states")
    private Integer productStates;


}
