package com.rui.yipai.pojo;

import com.rui.yipai.entity.ActivityInfo;
import com.rui.yipai.entity.UserInfo;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class RecommendActivity {

    //动态的id编号
    private Integer activityId;

    //动态的发布者id编号
    private Integer userId;

    //动态封面图片
    private String coverPic;

    //动态的内容
    private String activityTxt;

    //动态的定位
    private String activityAddress;

    //动态的点赞人数
    private Integer activityLikesNumbers;

    //动态的发布者
    private UserInfo userInfo;


}
