package com.rui.yipai.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.rui.yipai.dao.UserReplyDaoMapper;
import com.rui.yipai.entity.UserReply;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.pojo.UserReplyVo;
import com.rui.yipai.service.UserReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@RestController
@RequestMapping("/yipai/userReply")
public class UserReplyController {
    @Autowired
    private UserReplyService userReplyService;
    @Autowired
    private UserReplyDaoMapper userReplyDaoMapper;

    @PostMapping("/add")
    public Result<?> add(@RequestBody UserReply comment) {
        comment.setCreateDate(LocalDateTime.now());
        boolean insertResult = userReplyService.save(comment);
        if (insertResult) {
            return Result.success(comment);
        } else {
            return Result.error("200","回复失败");
        }
    }

    @GetMapping
    public Result<?> del(Integer commentId) {
        boolean insertResult = userReplyService.removeById(commentId);
        if (insertResult) {
            return Result.success("删除回复成功");
        } else {
            return Result.error("500","删除回复失败");
        }
    }

    @GetMapping("/getPage")
    public Result<?> getPage(int commentId, int current) {
        PageHelper.startPage(current, 10);
        List<UserReplyVo> list = userReplyDaoMapper.getPage(commentId);
        PageInfo<UserReplyVo> objectPageInfo = new PageInfo<>(list);
        return Result.success(objectPageInfo);
    }
}
