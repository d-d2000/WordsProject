package com.rui.yipai.controller;

import com.rui.yipai.entity.ServiceInfo;
import com.rui.yipai.entity.TypeDetail;
import com.rui.yipai.pojo.ProductInfo;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.service.TypeDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@RestController
@RequestMapping("/yipai/typeDetail")
public class TypeDetailController {

    @Autowired
    TypeDetailService typeDetailService;

    @RequestMapping("/addProduct")
    public Result<?> addProduct(@RequestBody ProductInfo productInfo) {
        List<ServiceInfo> serviceInfo = productInfo.getSonService();
        TypeDetail typeDetail = productInfo.getServiceDetail();
        boolean flag = typeDetailService.addServiceInfo(typeDetail,serviceInfo);
        if(flag) return Result.success("success");
        return Result.error("0000","提交失败");
    }

    @RequestMapping("/updateState")
    public Result<?> updateState(int detailId, int state) {
        TypeDetail typeDetail = new TypeDetail();
        typeDetail.setDetailId(detailId);
        typeDetail.setProductStates(state);
        boolean flag = typeDetailService.updateById(typeDetail);
        if(flag) return Result.success("success");
        return Result.error("0000","失败");
    }

    @RequestMapping("/deleteProduct")
    public Result<?> updateState(int detailId) {
        boolean flag = typeDetailService.removeById(detailId);
        if(flag) return Result.success("success");
        return Result.error("0000","失败");
    }

}
