package com.rui.yipai.dao;

import com.rui.yipai.pojo.UserCommentVo;
import io.lettuce.core.dynamic.annotation.Param;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserCommentDaoMapper {
    @Select("select user_id,comment_id,activity_id,comment_msg,create_date,zan_count from user_comment "
            +"where activity_id=#{activity_id} order by comment_id desc")
    @Results({
            @Result(property = "userId", column = "user_id"),
            @Result(
                    property = "userInfo", column = "user_id",
                    one = @One(select = "com.rui.yipai.dao.UserActivityDaoMapper.getNameAndFace")
            )
    })
    List<UserCommentVo> getPage(@Param("activity_id") int activity_id);
}
