package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Getter
@Setter
@TableName("user_detail")
@ApiModel(value = "UserDetail对象", description = "")
public class UserDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("用户个人简介的id")
    @TableId(value = "user_brief_id", type = IdType.AUTO)
    private Integer userBriefId;

    @ApiModelProperty("用户对应的默认id")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty("用户会员，0：没有，1：等级1，以此类推")
    @TableField("user_vip")
    private Integer userVip;

    @ApiModelProperty("用户积分")
    @TableField("user_integral")
    private Integer userIntegral;

    @ApiModelProperty("用户所在地")
    @TableField("user_address")
    private String userAddress;

    @ApiModelProperty("用户生日")
    @TableField("user_birth")
    private LocalDate userBirth;

    @ApiModelProperty("用户学校")
    @TableField("user_school")
    private String userSchool;

    @ApiModelProperty("用户公司")
    @TableField("user_company")
    private String userCompany;

    @ApiModelProperty("用户个签")
    @TableField("user_brief_introduction")
    private String userBriefIntroduction;

    @ApiModelProperty("用户粉丝数量")
    @TableField("user_fans_num")
    private Integer userFansNum;

    @ApiModelProperty("用户的关注数量")
    @TableField("user_attention_num")
    private Integer userAttentionNum;

    @ApiModelProperty("用户关注的店铺商品的id")
    @TableField("user_collection")
    private String userCollection;

    @ApiModelProperty("用户的动态数量")
    @TableField("user_activity_num")
    private Integer userActivityNum;

    @ApiModelProperty("关注用户的人的id拼接")
    @TableField("user_attention")
    private String userAttention;

    @ApiModelProperty("用户性别，1：男，2：女")
    @TableField("user_sex")
    private Integer userSex;

    @ApiModelProperty("背景图片")
    @TableField("user_bgk")
    private String userBgk;

    @ApiModelProperty("用户点赞数")
    @TableField("user_liked_num")
    private Integer userLikedNum;
}
