package com.rui.yipai.dao;

import com.rui.yipai.entity.ActivityInfo;
import com.rui.yipai.entity.UserInfo;
import com.rui.yipai.pojo.CollectionActivity;
import com.rui.yipai.pojo.HomePageInfo;
import com.rui.yipai.pojo.RecommendActivity;
import io.lettuce.core.dynamic.annotation.Param;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserActivityDaoMapper {

    //查询个人主页的信息
    @Select("select user_id,user_bgk,user_fans_num,user_attention_num,user_liked_num,user_brief_introduction "
    +"from user_detail where user_id=#{user_id}")
    @Results({
            @Result(property = "userId",column = "user_id"),
            @Result(
                    property = "userActivityInfo",column = "user_id",
                    many = @Many(select = "com.rui.yipai.dao.UserActivityDaoMapper.getTenActivityToHomePage")
            ),
            @Result(
                    property = "userInfo",column = "user_id",
                    one = @One(select = "com.rui.yipai.dao.UserActivityDaoMapper.getNameAndFace")
            )
    })
    HomePageInfo getHomePageInfo(@Param("user_id") int user_id);

    //页面加载的时候的10条动态
    @Select("select activity_id,cover_pic,activity_grant,activity_txt,activity_address,activity_likes_numbers from activity_info "
            + "where user_id=#{user_id} order by activity_id desc limit 10")
    List<ActivityInfo> getTenActivityToHomePage(@Param("user_id") int user_id);

    //查询用户头像，昵称
    @Select("select user_name,user_face from user_info where user_id=#{user_id}")
    UserInfo getNameAndFace(@Param("user_id") int user_id);

    //首页查询推荐动态信息
    @Select("select activity_id,user_id,cover_pic,activity_txt,activity_address,activity_likes_numbers from activity_info "
    +"where activity_grant=0 order by activity_id desc")
    @Results({
            @Result(property = "userId", column = "user_id"),
            @Result(
                    property = "userInfo", column = "user_id",
                    one = @One(select = "com.rui.yipai.dao.UserActivityDaoMapper.getNameAndFace")
            )
    })
    List<RecommendActivity> getRecommendActivityPage();

    //查询同城的动态
    @Select("select activity_id,user_id,cover_pic,activity_txt,activity_address,activity_likes_numbers from activity_info "
            +"where activity_grant=0 and activity_address like #{activity_address} order by activity_id desc")
    @Results({
            @Result(property = "userId", column = "user_id"),
            @Result(
                    property = "userInfo", column = "user_id",
                    one = @One(select = "com.rui.yipai.dao.UserActivityDaoMapper.getNameAndFace")
            )
    })
    List<RecommendActivity> getSameAddressActivityPage(@Param("activity_address") String activity_address);

    //批量查询
    @Select("select activity_id,cover_pic,activity_txt,activity_address,activity_likes_numbers from activity_info where find_in_set(activity_id,#{str})")
    List<ActivityInfo> getLikeActivityInfos(String str);

    @Select("select a.activity_id,a.user_id,a.cover_pic,a.activity_txt,a.activity_address,a.activity_likes_numbers,u.user_name,u.user_face from activity_info a ,user_info u where a.user_id = u.user_id and find_in_set(a.activity_id,#{str}) order by find_in_set(a.activity_id,#{str})")
    List<CollectionActivity> getCollectionActivity(String str);
}
