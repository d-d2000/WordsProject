package com.rui.yipai.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.rui.yipai.dao.UserActivityDaoMapper;
import com.rui.yipai.entity.ActivityInfo;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.service.ActivityInfoService;
import com.rui.yipai.utils.RedisUtil;
import io.lettuce.core.dynamic.annotation.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@RestController
@RequestMapping("/yipai/activityInfo")
public class ActivityInfoController {
    @Autowired
    ActivityInfoService activityInfoService;
    @Autowired
    RedisUtil redisUtil;

    /**
     * 添加动态
     * @param activityInfo
     * @return
     */
    @RequestMapping("/addActivity")
    public Result<?> addActivity(@RequestBody ActivityInfo activityInfo) {
        //动态存redis一个星期
//        redisUtil.setEx(activityInfo.getActivityId().toString(),activityInfo,7*24*60, TimeUnit.MINUTES);
        boolean res = activityInfoService.addActivity(activityInfo);
        if(res) return Result.success();
        else return Result.error("6","发表失败，请重新尝试！");
    }

    /**
     * 设置动态可见权限
     * @param activityId
     * @param activityGrant
     * @return
     */
    @GetMapping("/updateActivityGrant")
    public Result<?> updateActivityGrant(int activityId,int activityGrant) {
        boolean res = activityInfoService.updateActivityGrant(activityId,activityGrant);
        if(res) return Result.success(200);
        else return Result.error("7","权限更改失败,请稍后再试!");
    }

    /**
     * 推荐页面动态
     * @param pageNum
     * @param pageSize
     * @return
     */
    @GetMapping("/getRecommend")
    public Result<?> getRecommend(int pageNum, int pageSize) {
        return Result.success(activityInfoService.getRecommendActivity(pageNum, pageSize));
    }

    /**
     * 同城页面动态
     * @param pageNum
     * @param pageSize
     * @param address
     * @return
     */
    @GetMapping("/getSameAddress")
    public Result<?> getSameAddress(int pageNum,int pageSize,String address) {
        return Result.success(activityInfoService.getSameAddressActivity(pageNum, pageSize, address));
    }

    /**
     * 主页的分页查询
     * @param current
     * @param userId
     * @return
     */
    @GetMapping("/getMoreHomePageInfo")
    public Result<?> getMoreHomePageInfo(int current, int userId) {
        Page<ActivityInfo> page = new Page<>(current, 10);
        QueryWrapper<ActivityInfo> wrapper = new QueryWrapper<>();
        wrapper.select("activity_id","cover_pic","activity_grant","activity_txt","activity_address","activity_likes_numbers")
                .eq("user_id",userId)
                .orderByDesc("activity_id");
        return Result.success(activityInfoService.page(page,wrapper));
    }

    /**
     * 获取详情页
     * @param activityId
     * @return
     */
    @GetMapping("/getActivityDetail")
    public Result<?> getActivityDetail(int activityId) {
        return Result.success(activityInfoService.getActivityInfoByActivityId(activityId));
    }

    /**
     * 点赞
     * @param activityId
     * @param userId
     * @return
     */
    @GetMapping("/likeArticle")
    public Result<?> likeArticle(int activityId,int userId) {
            //score存时间戳
            //存到文章对应的点赞列表
            redisUtil.zAdd("article:"+activityId,userId+"",System.currentTimeMillis());
            //用户的点赞列表也同步更新
            redisUtil.lLeftPush("userLikeArticles:"+userId,activityId+",");
            return Result.success("111");
    }

    @Autowired
    UserActivityDaoMapper userActivityDaoMapper;

    @GetMapping("/selectLikeArticle")
    public Result<?> selectLikeArticle(int userId,Long start) {
        //1.先去redis查询
        if(!redisUtil.hasKey("userLikeArticles"+userId)) return Result.success("暂无点赞文章");
        else {
            Long len = redisUtil.lLen("userLikeArticles:" + userId);//列表长度方便分页
            StringBuilder str = new StringBuilder();
            List<String> strings = redisUtil.lRange("userLikeArticles:" + userId, start, start + 9);
            if(strings.size() == 0) return Result.success("empty");
            for (String string : strings) {
                str.append(string);
            }
            //拼接完成后查询数据库
            System.out.println(str.toString());
            List<ActivityInfo> likeActivityInfos = userActivityDaoMapper.getLikeActivityInfos(str.toString().substring(0,str.length()-1));
            return Result.success(likeActivityInfos);
        }
//        //2.若没有去数据库查询
//        return Result.success("22222");
    }
}
