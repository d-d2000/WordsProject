package com.rui.yipai.service;

import com.rui.yipai.entity.BusinessType;
import com.baomidou.mybatisplus.extension.service.IService;
import com.rui.yipai.pojo.ServiceType;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yr
 * @since 2023-01-12
 */
public interface BusinessTypeService extends IService<BusinessType> {
    boolean addService(List<ServiceType> list);

    BusinessType myService();
}
