package com.rui.yipai.service;

import com.rui.yipai.entity.BusinessInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yr
 * @since 2022-10-20
 */
public interface BusinessInfoService extends IService<BusinessInfo> {
    boolean applyBoss(BusinessInfo businessInfo);

    int businessState();
}
