package com.rui.yipai.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.utils.JwtUtil;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class JwtTokenInterceptor implements HandlerInterceptor {
    @Resource
    private RedisTemplate<String,Object> redisTemplate;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws IOException {
        String token = request.getHeader("token");
        System.out.println("token->>"+token);
        Map<String,Object> map = new HashMap<>();
        /**
         * 判断token格式正确性
         */
        if (JwtUtil.verify(token) == 0) {
            /**
             * 判断是否是登录状态
             */
            System.out.println("token格式不对");
            Result rs = Result.error("111","token格式不对！");
            String json = new ObjectMapper().writeValueAsString(rs);
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().println(json);
            return false;

        } else {
            Long expire = redisTemplate.getExpire(token);
            if (expire > 0) {
                System.out.println("放行");
                /** token延时 **/
                redisTemplate.expire(token, 60*24*7L, TimeUnit.MINUTES);
                return true;
            } else {
                System.out.println("token已经过期了");
                Result rs = Result.error("999","token过期了！");
                String json = new ObjectMapper().writeValueAsString(rs);
                response.setContentType("application/json;charset=UTF-8");
                response.getWriter().println(json);
                return false;
            }
        }

    }
}
