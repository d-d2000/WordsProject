package com.rui.yipai.service.serviceImpl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.rui.yipai.dao.UserActivityDaoMapper;
import com.rui.yipai.entity.ActivityInfo;
import com.rui.yipai.entity.CollectionInfo;
import com.rui.yipai.entity.UserInfo;
import com.rui.yipai.mapper.ActivityInfoMapper;
import com.rui.yipai.mapper.CollectionInfoMapper;
import com.rui.yipai.pojo.RecommendActivity;
import com.rui.yipai.service.ActivityInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.rui.yipai.utils.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Service
public class ActivityInfoServiceImpl extends ServiceImpl<ActivityInfoMapper, ActivityInfo> implements ActivityInfoService {

    @Autowired
    ActivityInfoMapper activityInfoMapper;

    @Autowired
    UserActivityDaoMapper userActivityDaoMapper;

    @Autowired
    CollectionInfoMapper collectionInfoMapper;

    @Autowired
    RedisTemplate redisTemplate;

    /**
     * 上传动态
     * @param activityInfo
     * @return
     */
    @Override
    public boolean addActivity(ActivityInfo activityInfo) {
        activityInfo.setActivityTime(LocalDateTime.now());
        int flag = activityInfoMapper.insert(activityInfo);
        if(flag > 0) return true;
        return false;
    }


    /**
     * 更新用户动态的可见范围
     * @param activityId
     * @param activityGrant
     * @return
     */
    @Override
    public boolean updateActivityGrant(int activityId, int activityGrant) {
        UpdateWrapper<ActivityInfo> wrapper = new UpdateWrapper<>();
        wrapper.set("activity_grant",activityGrant)
                .eq("activity_id",activityId);
        int flag = activityInfoMapper.update(null,wrapper);
        if(flag > 0) return true;
        return false;
    }

    /**
     * 获取推荐动态
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public List<RecommendActivity> getRecommendActivity(int pageNum,int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<RecommendActivity> recommendActivities = userActivityDaoMapper.getRecommendActivityPage();
        PageInfo<RecommendActivity> objectPageInfo = new PageInfo<>(recommendActivities);
        return objectPageInfo.getList();
    }

    /**
     * 获取同城动态
     * @param pageNum
     * @param pageSize
     * @param activityAddress
     * @return
     */
    @Override
    public List<RecommendActivity> getSameAddressActivity(int pageNum, int pageSize,String activityAddress) {
        PageHelper.startPage(pageNum, pageSize);
        List<RecommendActivity> recommendActivities = userActivityDaoMapper.
                getSameAddressActivityPage('%' + activityAddress + ":%");
        PageInfo<RecommendActivity> objectPageInfo = new PageInfo<>(recommendActivities);
        return objectPageInfo.getList();
    }

    /**
     * 通过用户动态ID查询具体的动态
     * @param activityId
     * @return
     */
    @Override
    public ActivityInfo getActivityInfoByActivityId(int activityId) {
        QueryWrapper<ActivityInfo> wrapper = new QueryWrapper<>();
        wrapper.select("business_id","activity_comments_numbers","activity_forwarding_numbers",
                "activity_pic_list","activity_time")
                .eq("activity_id",activityId);
        ActivityInfo  activityInfo= activityInfoMapper.selectOne(wrapper);
        //查询收藏状态
        UserInfo userInfo = (UserInfo) redisTemplate
                .opsForValue()
                .get(UserRequest.getCurrentToken());

        int userId = userInfo.getUserId();
        QueryWrapper<CollectionInfo> collectionInfoQueryWrapper = new QueryWrapper<>();

        collectionInfoQueryWrapper.select("user_id","detail_id")
                .eq("user_id",userId);

        CollectionInfo collectionInfo = collectionInfoMapper.selectOne(collectionInfoQueryWrapper);
        if(collectionInfo.getDetailId().indexOf(activityId+",") != -1) activityInfo.setCollectionState(true);
        else activityInfo.setCollectionState(false);
//        //收藏数量
//        activityInfo.setCollectionNum(collectionInfo.getDetailId().length() / 2);
        return activityInfo;
    }


}
