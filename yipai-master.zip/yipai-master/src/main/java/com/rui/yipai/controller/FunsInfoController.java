package com.rui.yipai.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.rui.yipai.entity.FunsInfo;
import com.rui.yipai.service.FunsInfoService;
import io.netty.util.internal.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@RestController
@RequestMapping("/yipai/funsInfo")
public class FunsInfoController {
    @Autowired
    private FunsInfoService funsInfoService;
    public Boolean updateFuns(int userId,int funsId, boolean attention){
        boolean update = false;
        String toUserId = String.valueOf(funsId);

        QueryWrapper<FunsInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);
        FunsInfo funsInfo=funsInfoService.getOne(queryWrapper);
        String attentions = funsInfo.getUserFuns();
        if(attention) {
            if(StringUtil.isNullOrEmpty(attentions)) {
                attentions = "::"+toUserId+"::";
                update = true;
            } else {
                if(!attentions.contains("::"+toUserId+"::")) {
                    attentions +=toUserId+"::";
                    update = true;
                }
            }
        } else {
            if(!StringUtil.isNullOrEmpty(attentions)) {
                if(attentions.contains("::"+toUserId+"::")) {
                    attentions.replace("::"+toUserId+"::", "::");
                    update = true;
                }
            }
        }
        if(update) {
            funsInfo.setUserFuns(attentions);
            return funsInfoService.updateById(funsInfo);
        }
        return true;
    }
}
