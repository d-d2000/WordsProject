package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Getter
@Setter
@TableName("user_info")
@ApiModel(value = "UserInfo对象", description = "")
public class UserInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField(exist = false)
    private Integer fansNums;

    @ApiModelProperty("用户默认的id")
    @TableId(value = "user_id", type = IdType.AUTO)
    private Integer userId;

    @ApiModelProperty("用户昵称")
    @TableField("user_name")
    private String userName;

    @ApiModelProperty("用户的密码")
    @TableField("user_pass")
    private String userPass;

    @ApiModelProperty("用户联系电话，采用手机号码登陆")
    @TableField("user_tel")
    private String userTel;

    @ApiModelProperty("用户的邮箱")
    @TableField("user_email")
    private String userEmail;

    @ApiModelProperty("用户类型，1代表普通用户，2代表商家")
    @TableField("user_type")
    private Integer userType;

    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @ApiModelProperty("用户注册时间")
    @TableField("user_register_time")
    private LocalDateTime userRegisterTime;

    @ApiModelProperty("用户头像")
    @TableField("user_face")
    private String userFace;

    @ApiModelProperty("用户账号的状态，1：正常，2：异常，3：待注销状态")
    @TableField("user_states")
    private Integer userStates;

    @ApiModelProperty("删除状态")
    @TableField("deleted")
    @TableLogic
    private Integer deleted;

}
