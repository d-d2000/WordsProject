package com.rui.yipai.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.rui.yipai.dao.BusinessReplyDaoMapper;
import com.rui.yipai.entity.BusinessReply;
import com.rui.yipai.pojo.BusinessReplyVo;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.service.BusinessReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@RestController
@RequestMapping("/yipai/businessReply")
public class BusinessReplyController {
    @Autowired
    private BusinessReplyService businessReplyService;
    @Autowired
    private BusinessReplyDaoMapper businessReplyDaoMapper;

    @PostMapping("/add")
    public Result<?> add(@RequestBody BusinessReply comment) {
        comment.setCreateDate(LocalDateTime.now());
        boolean insertResult = businessReplyService.save(comment);
        if (insertResult) {
            return Result.success(comment);
        } else {
            return Result.error("200","回复失败");
        }
    }

    @GetMapping
    public Result<?> del(Integer commentId) {
        boolean insertResult = businessReplyService.removeById(commentId);
        if (insertResult) {
            return Result.success("删除回复成功");
        } else {
            return Result.error("500","删除回复失败");
        }
    }

    @GetMapping("/getPage")
    public Result<?> getPage(int businessCommentId, int current) {
        PageHelper.startPage(current, 10);
        List<BusinessReplyVo> list = businessReplyDaoMapper.getPage(businessCommentId);
        PageInfo<BusinessReplyVo> objectPageInfo = new PageInfo<>(list);
        return Result.success(objectPageInfo);
    }
}
