package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Getter
@Setter
@TableName("funs_info")
@ApiModel(value = "FunsInfo对象", description = "")
public class FunsInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("粉丝表id")
    @TableId("funs_info_id")
    private Integer funsInfoId;

    @ApiModelProperty("用户id")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty("用户粉丝id的拼接")
    @TableField("user_funs")
    private String userFuns;


}
