package com.rui.yipai.dao;


import com.rui.yipai.entity.UserInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;


@Mapper
public interface UserInfoDaoMapper {
  //使用密码登录查询用户信息
  @Select("select user_id,user_name,user_tel,user_email,user_type,user_register_time,user_face "
    +"from user_info where user_tel=#{user.userTel} and user_pass=#{user.userPass}")
  UserInfo getLoginUserInfo(@Param("user") UserInfo user);

  //注册时查询是否存在注册手机号
  @Select("select user_tel from user_info where user_tel=#{userTel}")
  String isRegister(@Param("userTel") String userTel);

  //使用验证码登陆查询用户信息
  @Select("select user_id,user_name,user_tel,user_register_time,user_face,user_type "
          +"from user_info where user_tel=#{userTel}")
  UserInfo getUserInfo(@Param("userTel") String userTel);
}
