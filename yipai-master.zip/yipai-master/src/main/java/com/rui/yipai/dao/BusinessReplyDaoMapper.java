package com.rui.yipai.dao;

import com.rui.yipai.pojo.BusinessReplyVo;
import io.lettuce.core.dynamic.annotation.Param;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface BusinessReplyDaoMapper {
    @Select("select from_user_id,to_user_id,business_reply_id,business_comment_id,comment_msg,create_date from business_reply "
            +"where business_comment_id=#{business_comment_id} order by business_reply_id desc")
    @Results({
            @Result(property = "fromUserId", column = "from_user_id"),
            @Result(property = "toUserId", column = "to_user_id"),
            @Result(
                    property = "fromUserInfo", column = "from_user_id",
                    one = @One(select = "com.rui.yipai.dao.UserActivityDaoMapper.getNameAndFace")
            ),
            @Result(
                    property = "toUserInfo", column = "to_user_id",
                    one = @One(select = "com.rui.yipai.dao.UserActivityDaoMapper.getNameAndFace")
            )
    })
    List<BusinessReplyVo> getPage(@Param("business_comment_id") int businessCommentId);
}
