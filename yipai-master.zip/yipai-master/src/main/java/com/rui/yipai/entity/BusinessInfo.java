package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-10-20
 */
@Getter
@Setter
@TableName("business_info")
@ApiModel(value = "BusinessInfo对象", description = "")
public class BusinessInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("商家默认的id")
    @TableId("business_id")
    private Integer businessId;

    @ApiModelProperty("商家的店名")
    @TableField("business_name")
    private String businessName;

    @ApiModelProperty("商家的具体地址")
    @TableField("business_address")
    private String businessAddress;

    @ApiModelProperty("商家的邮箱，用于通知商家消息")
    @TableField("business_email")
    private String businessEmail;

    @ApiModelProperty("商家注册的身份证")
    @TableField("business_ID_card")
    private String businessIdCard;

    @ApiModelProperty("该身份证的姓名")
    @TableField("business_ID_name")
    private String businessIdName;

    @ApiModelProperty("店铺的头像")
    @TableField("business_pic")
    private String businessPic;

    @ApiModelProperty("店铺的营业状态，0：非营业状态，1：营业状态")
    @TableField("business_states")
    private Integer businessStates;

    @ApiModelProperty("店铺每周工作时间")
    @TableField("week_do")
    private String weekDo;

    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty("审核状态 0审核中1审核通过2审核失败！")
    @TableField("state")
    private Integer state;


}
