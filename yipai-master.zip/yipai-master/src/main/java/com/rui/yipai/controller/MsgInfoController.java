package com.rui.yipai.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@RestController
@RequestMapping("/yipai/msgInfo")
public class MsgInfoController {

}
