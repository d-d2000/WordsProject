package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-10-12
 */
@Getter
@Setter
@TableName("user_likes_info")
@ApiModel(value = "UserLikesInfo对象", description = "")
public class UserLikesInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("用户的点赞表")
    @TableId(value = "user_likes_id", type = IdType.AUTO)
    private Integer userLikesId;

    @ApiModelProperty("用户id")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty("点赞文章的id拼接")
    @TableField("activity_id_string")
    private String activityIdString;


}
