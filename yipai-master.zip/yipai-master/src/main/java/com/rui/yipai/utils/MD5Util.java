package com.rui.yipai.utils;

import org.apache.commons.codec.digest.DigestUtils;

public class MD5Util {
  public static String dbSalt = "dbSalt";//后台加盐

  public static String md5(String str){
    return DigestUtils.md5Hex(str);
  }

  //第二次加密。第二次加密会用前端传过来的密文再加密一次
  public static String backToDb(String str){
    return md5(str + dbSalt);
  }
}
