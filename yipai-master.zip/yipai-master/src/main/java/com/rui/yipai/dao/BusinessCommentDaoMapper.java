package com.rui.yipai.dao;

import com.rui.yipai.pojo.BusinessCommentVo;
import io.lettuce.core.dynamic.annotation.Param;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface BusinessCommentDaoMapper {
    @Select("select user_id,business_comment_id,detail_id,comment_msg,create_date,zan_count from business_comment "
            +"where detail_id=#{detailId} order by business_comment_id desc")
    @Results({
            @Result(property = "userId", column = "user_id"),
            @Result(
                    property = "userInfo", column = "user_id",
                    one = @One(select = "com.rui.yipai.dao.UserActivityDaoMapper.getNameAndFace")
            )
    })
    List<BusinessCommentVo> getPage(@Param("detail_id") int detailId);
}
