package com.rui.yipai.dao;

import com.rui.yipai.pojo.BusinessVo;
import io.lettuce.core.dynamic.annotation.Param;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface BusinessDaoMapper {
    @Select("select b.* from business_info b " +
            "where b.business_id=#{business_id}")
    @Results({
            @Result(property = "businessId", column = "business_id"),
            @Result(
                    property = "businessType", column = "business_id",
                    one = @One(select = "com.rui.yipai.dao.BusinessTypeDaoMapper.getByBusinessId")
            )
    })
    List<BusinessVo> list(@Param("business_id") int business_id);

    @Select("select b.* from business_info b ")
    @Results({
            @Result(property = "businessId", column = "business_id"),
            @Result(
                    property = "businessType", column = "business_id",
                    one = @One(select = "com.rui.yipai.dao.BusinessTypeDaoMapper.getByBusinessId")
            )
    })
    List<BusinessVo> listAll();
}
