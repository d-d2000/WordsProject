package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2023-01-12
 */
@Getter
@Setter
@TableName("business_type")
@ApiModel(value = "BusinessType对象", description = "")
public class BusinessType implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("类型默认id")
    @TableId(value = "type_id", type = IdType.AUTO)
    private Integer typeId;

    @ApiModelProperty("商家id")
    @TableField("business_id")
    private Integer businessId;

    @ApiModelProperty("1：肖像照")
    @TableField("portrait")
    private Integer portrait;

    @ApiModelProperty("2：婚纱照")
    @TableField("wedding")
    private Integer wedding;

    @ApiModelProperty("3：证件照")
    @TableField("certificates")
    private Integer certificates;

    @ApiModelProperty("4：孕妇照")
    @TableField("gravida")
    private Integer gravida;

    @ApiModelProperty("5：写真")
    @TableField("photo")
    private Integer photo;

    @ApiModelProperty("6：写真照")
    @TableField("image")
    private Integer image;

    @ApiModelProperty("7：婚礼跟拍")
    @TableField("wedding_follow")
    private Integer weddingFollow;

    @ApiModelProperty("8：产品拍摄")
    @TableField("product")
    private Integer product;

    @ApiModelProperty("9：宠物")
    @TableField("pets")
    private Integer pets;

    @ApiModelProperty("10：婴儿纪念")
    @TableField("baby")
    private Integer baby;

    @ApiModelProperty("风格的图片")
    @TableField("kind_pic")
    private String kindPic;


}
