package com.rui.yipai.service.serviceImpl;

import com.rui.yipai.entity.UserComment;
import com.rui.yipai.mapper.UserCommentMapper;
import com.rui.yipai.service.UserCommentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Service
public class UserCommentServiceImpl extends ServiceImpl<UserCommentMapper, UserComment> implements UserCommentService {

}
