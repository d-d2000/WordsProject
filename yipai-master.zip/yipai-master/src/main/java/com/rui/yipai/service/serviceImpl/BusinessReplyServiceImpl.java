package com.rui.yipai.service.serviceImpl;

import com.rui.yipai.entity.BusinessReply;
import com.rui.yipai.mapper.BusinessReplyMapper;
import com.rui.yipai.service.BusinessReplyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Service
public class BusinessReplyServiceImpl extends ServiceImpl<BusinessReplyMapper, BusinessReply> implements BusinessReplyService {

}
