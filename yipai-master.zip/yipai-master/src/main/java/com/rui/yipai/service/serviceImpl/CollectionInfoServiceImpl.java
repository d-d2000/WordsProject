package com.rui.yipai.service.serviceImpl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.rui.yipai.dao.UserActivityDaoMapper;
import com.rui.yipai.entity.CollectionInfo;
import com.rui.yipai.entity.UserInfo;
import com.rui.yipai.mapper.CollectionInfoMapper;
import com.rui.yipai.pojo.CollectionActivity;
import com.rui.yipai.service.CollectionInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.rui.yipai.utils.RedisUtil;
import com.rui.yipai.utils.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-10-13
 */
@Service
public class CollectionInfoServiceImpl extends ServiceImpl<CollectionInfoMapper, CollectionInfo> implements CollectionInfoService {

    @Autowired
    RedisTemplate redisTemplate;

    @Autowired
    RedisUtil redisUtil;

    @Autowired
    CollectionInfoMapper collectionInfoMapper;

    @Autowired
    UserActivityDaoMapper userActivityDaoMapper;


    /**
     * 用户收藏动态
     * @param activityId
     * @return
     */
    @Override
    public boolean collectionActivity(int activityId,int kind) {
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        int userId = userInfo.getUserId();

        //拼接到数据库
        QueryWrapper<CollectionInfo> collectionInfoQueryWrapper = new QueryWrapper<>();
        collectionInfoQueryWrapper.select("detail_id","user_id").eq("user_id",userId);
        CollectionInfo collectionInfo = collectionInfoMapper.selectOne(collectionInfoQueryWrapper);
        String str = "";
        str = collectionInfo.getDetailId() == null ? "" : collectionInfo.getDetailId();
        if(kind == 1) str ="" + activityId + "," + str;
        else str = str.replace(activityId + ",","");

        //查询redis是否有记录
        Boolean aBoolean = redisUtil.hasKey("userCollectionActivity" + userId);
        if(aBoolean.booleanValue()) {
            //设置十分钟失效
            redisUtil.setEx("userCollectionActivity" + userId,str,10L, TimeUnit.MINUTES);
        }

        //更新数据库
        UpdateWrapper<CollectionInfo> collectionInfoUpdateWrapper = new UpdateWrapper<>();
        collectionInfoUpdateWrapper.eq("user_id",userId).set("detail_id",str);
        int flag = collectionInfoMapper.update(null,collectionInfoUpdateWrapper);
        if(flag > 0) return true;
        else return false;
    }

    @Override
    public List<CollectionActivity> getCollectionActivity(int getCount) {
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        int userId = userInfo.getUserId();

        //先去redis查询是否有对应的缓存，没有则第一遍去数据库查询，在添加到redis
        Boolean aBoolean = redisUtil.hasKey("userCollectionActivity" + userId);
        if(aBoolean.booleanValue()) {
            String str = (String) redisUtil.get("userCollectionActivity" + userId);
            System.out.println(str);
            return getPartCollectionActivity(getCount,str);
        } else {
            //没有则去数据库查询，在缓存至redis
            QueryWrapper<CollectionInfo> collectionInfoQueryWrapper = new QueryWrapper<>();
            collectionInfoQueryWrapper.select("user_id","detail_id")
                    .eq("user_id",userId);
            CollectionInfo collectionInfo = collectionInfoMapper.selectOne(collectionInfoQueryWrapper);
            String idStr = collectionInfo.getDetailId();
            //设置十分钟失效
            redisUtil.setEx("userCollectionActivity" + userId,idStr,10L, TimeUnit.MINUTES);
            return getPartCollectionActivity(getCount,idStr);
        }
    }

    //截取对应数据
    private List<CollectionActivity> getPartCollectionActivity(int getCount,String str) {
        //判断截断的长度是否超过字符串
        str = str.substring(0,str.length() - 1);
        String[] split = str.split(",");
        String collectionStr = "";
        if(10 * (getCount + 1) >= split.length) {
            for(int i = 10 * (getCount); i < split.length;i++) {
                collectionStr += split[i] + ",";
            }
        } else {
            for(int i = 10 * (getCount); i < 10;i++) {
                collectionStr += split[i] + ",";
            }
        }
        List<CollectionActivity> collectionActivityList = userActivityDaoMapper.getCollectionActivity(collectionStr);
        return collectionActivityList;
    }
}
