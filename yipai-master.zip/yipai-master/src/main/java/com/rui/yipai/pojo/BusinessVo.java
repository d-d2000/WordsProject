package com.rui.yipai.pojo;

import com.rui.yipai.entity.BusinessType;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class BusinessVo {

    private Integer businessId;

    private String businessName;

    private String businessAddress;

    private String businessEmail;

    private String businessIdCard;

    private String businessIdName;

    private String businessPic;

    private Integer businessStates;

    private String weekDo;

    private Integer userId;

    private Integer state;

    private BusinessType businessType;

    private List<TypeDetailVo> typeDetailVos;

}
