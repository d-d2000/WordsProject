package com.rui.yipai.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.rui.yipai.dao.UserCommentDaoMapper;
import com.rui.yipai.entity.UserComment;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.pojo.UserCommentVo;
import com.rui.yipai.service.UserCommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@RestController
@RequestMapping("/yipai/userComment")
public class UserCommentController {
    
    @Autowired
    private UserCommentService userCommentService;
    @Autowired
    private UserCommentDaoMapper userCommentDaoMapper;

    @PostMapping("/add")
    public Result<?> add(@RequestBody UserComment comment) {
        comment.setCreateDate(LocalDateTime.now());
        comment.setZanCount(0);
        comment.setZanId("");
        boolean insertResult = userCommentService.save(comment);
        if (insertResult) {
            return Result.success(comment);
        } else {
            return Result.error("200","评论失败");
        }
    }

    @GetMapping
    public Result<?> del(Integer commentId) {
        boolean insertResult = userCommentService.removeById(commentId);
        if (insertResult) {
            return Result.success("删除评论成功");
        } else {
            return Result.error("500","删除评论失败");
        }
    }

    @GetMapping("/getPage")
    public Result<?> getPage(int activityId, int current) {
        PageHelper.startPage(current, 10);
        List<UserCommentVo> list = userCommentDaoMapper.getPage(activityId);
        PageInfo<UserCommentVo> objectPageInfo = new PageInfo<>(list);
        return Result.success(objectPageInfo);
    }
}
