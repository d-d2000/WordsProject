package com.rui.yipai.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.rui.yipai.dao.BusinessCommentDaoMapper;
import com.rui.yipai.entity.BusinessComment;
import com.rui.yipai.pojo.BusinessCommentVo;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.service.BusinessCommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@RestController
@RequestMapping("/yipai/businessComment")
public class BusinessCommentController {
    @Autowired
    private BusinessCommentService businessCommentService;
    @Autowired
    private BusinessCommentDaoMapper businessCommentDaoMapper;

    @PostMapping("/add")
    public Result<?> add(@RequestBody BusinessComment comment) {
        comment.setCreateDate(LocalDateTime.now());
        comment.setZanCount(0);
        comment.setZanId("");
        boolean insertResult = businessCommentService.save(comment);
        if (insertResult) {
            return Result.success(comment);
        } else {
            return Result.error("500","评论失败");
        }
    }

    @GetMapping
    public Result<?> del(Integer commentId) {
        boolean insertResult = businessCommentService.removeById(commentId);
        if (insertResult) {
            return Result.success("删除评论成功");
        } else {
            return Result.error("500","删除评论失败");
        }
    }
    @GetMapping("/getPage")
    public Result<?> getPage(int detailId, int current) {
        PageHelper.startPage(current, 10);
        List<BusinessCommentVo> list = businessCommentDaoMapper.getPage(detailId);
        PageInfo<BusinessCommentVo> objectPageInfo = new PageInfo<>(list);
        return Result.success(objectPageInfo);
    }

}
