package com.rui.yipai.service;

import com.rui.yipai.entity.ServiceInfo;
import com.rui.yipai.entity.TypeDetail;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
public interface TypeDetailService extends IService<TypeDetail> {
        public boolean addServiceInfo(TypeDetail typeDetail, List<ServiceInfo> serviceInfoList);
}
