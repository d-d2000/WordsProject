package com.rui.yipai.utils;

import com.aliyun.dysmsapi20170525.models.SendSmsRequest;
import com.aliyun.teaopenapi.models.*;

import java.util.Random;

public class VerifyUtils {



  /**
   * 使用AK&SK初始化账号Client
   * @param accessKeyId
   * @param accessKeySecret
   * @return Client
   * @throws Exception
   */
  public static com.aliyun.dysmsapi20170525.Client createClient(String accessKeyId, String accessKeySecret) throws Exception {
    Config config = new Config()
      // 您的AccessKey ID
      .setAccessKeyId(accessKeyId)
      // 您的AccessKey Secret
      .setAccessKeySecret(accessKeySecret);
    // 访问的域名
    config.endpoint = "dysmsapi.aliyuncs.com";
    return new com.aliyun.dysmsapi20170525.Client(config);
  }

  /**
   * 生成短信验证码
   * @return
   * @throws Exception
   */
  public static String getVerify(String userTel) throws Exception {
    int VERIFY_CODE =  new Random().nextInt(899999)+100000;//随机生成6位数
    com.aliyun.dysmsapi20170525.Client client = VerifyUtils.createClient("LTAI5tJ8qFX9cbHGc7WZQQzx", "RCkcHoHM7nARxdS90awKiAqxNh3VXU");
    SendSmsRequest sendSmsRequest = new SendSmsRequest()
      .setSignName("阿里云短信测试")
      .setTemplateCode("SMS_154950909")
      .setPhoneNumbers(userTel)
      .setTemplateParam("{\"code\":\""+ VERIFY_CODE +"\"}");
    // 复制代码运行请自行打印 API 的返回值
    client.sendSms(sendSmsRequest);
    return VERIFY_CODE + "";
  }
}
