package com.rui.yipai.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.rui.yipai.entity.UserDetail;
import com.rui.yipai.entity.UserInfo;
import com.rui.yipai.pojo.HomePageInfo;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.service.UserDetailService;
import com.rui.yipai.utils.UserRequest;
import io.netty.util.internal.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@RestController
@RequestMapping("/yipai/userDetail")
public class UserDetailController {

    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    UserDetailService userDetailService;

    @GetMapping("/getHomePage")
    public Result<?> getHomePage(int userId){
        HomePageInfo homePageInfo = userDetailService.UserHomePageInfo(userId);
        if(homePageInfo != null) return Result.success(homePageInfo);
        else return Result.error("000","重新加载");
    }


    @Autowired
    private FunsInfoController funsInfoController;
    @PostMapping("/updateAttention")
    @Transactional
    public Result<?> updateAttention(int userId, boolean attention){
        boolean update = false;
        String toUserId = String.valueOf(userId);
        //获取businessId
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        QueryWrapper<UserDetail> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userInfo.getUserId());
        UserDetail userDetail=userDetailService.getOne(queryWrapper);
        String attentions = userDetail.getUserAttention();
        if(attention) {
            if(StringUtil.isNullOrEmpty(attentions)) {
                attentions = "::"+toUserId+"::";
                update = true;
            } else {
                if(!attentions.contains("::"+toUserId+"::")) {
                    attentions +=toUserId+"::";
                    update = true;
                }
            }
        } else {
            if(!StringUtil.isNullOrEmpty(attentions)) {
                if(attentions.contains("::"+toUserId+"::")) {
                    attentions.replace("::"+toUserId+"::", "::");
                    update = true;
                }
            }
        }
        if(update) {
            QueryWrapper<UserDetail> queryWrapper0 = new QueryWrapper<>();
            queryWrapper0.eq("user_id", userId);
            UserDetail toUser=userDetailService.getOne(queryWrapper0);
            if(attention) {
                userDetail.setUserAttentionNum(userDetail.getUserAttentionNum()+1);
                toUser.setUserFansNum(toUser.getUserFansNum()+1);
                funsInfoController.updateFuns(userId, userInfo.getUserId(), true);
            } else {
                userDetail.setUserAttentionNum(userDetail.getUserAttentionNum()-1);
                toUser.setUserFansNum(toUser.getUserFansNum()-1);
                funsInfoController.updateFuns(userId, userInfo.getUserId(), false);
            }
            userDetail.setUserAttention(attentions);
            userDetailService.updateById(userDetail);
            userDetailService.updateById(toUser);
        }
        return Result.success(true);
    }

    @PostMapping("/isAttention")
    public Result<?> isAttention(int userId) {
        boolean isAttention = false;
        String toUserId = String.valueOf(userId);
        //获取businessId
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        QueryWrapper<UserDetail> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userInfo.getUserId());
        String attentions = userDetailService.getOne(queryWrapper).getUserAttention();
        if(!StringUtil.isNullOrEmpty(attentions)) {
            if(attentions.contains("::"+toUserId+"::")) {
                isAttention = true;
            }
        }
        return Result.success(isAttention);
    }

}
