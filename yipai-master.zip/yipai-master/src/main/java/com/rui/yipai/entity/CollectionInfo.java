package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-10-13
 */
@Getter
@Setter
@TableName("collection_info")
@ApiModel(value = "CollectionInfo对象", description = "")
public class CollectionInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("收藏表id")
    @TableId("collection_id")
    private Integer collectionId;

    @ApiModelProperty("用户id")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty("收藏内容的id")
    @TableField("detail_id")
    private String detailId;


}
