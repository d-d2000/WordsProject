package com.rui.yipai.controller;

import com.rui.yipai.pojo.CollectionActivity;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.service.CollectionInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-10-13
 */
@RestController
@RequestMapping("/yipai/collectionInfo")
public class CollectionInfoController {
    @Autowired
    CollectionInfoService collectionInfoService;

    @GetMapping("/collection")
    public Result<?> collection(int activityId) {
        boolean flag = collectionInfoService.collectionActivity(activityId,1);
        if(flag) return Result.success("收藏成功");
        else return Result.error("0000","收藏失败");
    }

    @GetMapping("/disCollection")
    public Result<?> disCollection(int activityId) {
        boolean flag = collectionInfoService.collectionActivity(activityId,0);
        if(flag) return Result.success("取消成功");
        else return Result.error("0000","取消失败");
    }

    @GetMapping("/getCollection")
    public Result<?> getCollection(int getCount) {
        List<CollectionActivity> collectionActivity = collectionInfoService.getCollectionActivity(getCount);
        if(!collectionActivity.isEmpty()) return Result.success(collectionActivity);
        else return Result.error("0000","查看失败");
    }
}
