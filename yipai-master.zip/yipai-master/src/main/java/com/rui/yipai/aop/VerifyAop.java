package com.rui.yipai.aop;

import com.rui.yipai.utils.RedisUtil;
import com.rui.yipai.utils.VerifyUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Aspect
@Component
public class VerifyAop {

    @Autowired
    RedisUtil redisUtil;

    //定义切点
    @Pointcut("execution(* com.rui.yipai.controller.VerifyController.*(..))")
    public void verifyControllerPointcut(){};

    @Before("verifyControllerPointcut()")
    public void before(JoinPoint joinPoint) {
    //接收被代理方法的参数,这里是用户的电话号码
    Object[] args = joinPoint.getArgs();
    for (Object arg : args) {
        try {
            //调用封装的短信发送
            String sms = VerifyUtils.getVerify((String) arg);
            //获取验证码并将验证码存入Redis设置三分钟失效
            redisUtil.setEx((String) arg,sms,3L, TimeUnit.MINUTES);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
  }
}
