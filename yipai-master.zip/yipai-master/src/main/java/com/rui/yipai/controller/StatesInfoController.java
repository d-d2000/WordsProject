package com.rui.yipai.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.rui.yipai.dao.BusinessDaoMapper;
import com.rui.yipai.dao.StatesInfoDaoMapper;
import com.rui.yipai.dao.TypeDetailDaoMapper;
import com.rui.yipai.entity.BusinessInfo;
import com.rui.yipai.entity.StatesInfo;
import com.rui.yipai.entity.TypeDetail;
import com.rui.yipai.entity.UserInfo;
import com.rui.yipai.pojo.BusinessVo;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.pojo.StatesInfoVo;
import com.rui.yipai.service.BusinessInfoService;
import com.rui.yipai.service.StatesInfoService;
import com.rui.yipai.utils.UserRequest;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@RestController
@RequestMapping("/yipai/statesInfo")
public class StatesInfoController {
    @Autowired
    RedisTemplate redisTemplate;
    @Autowired
    private BusinessInfoService businessInfoService;
    @Autowired
    private StatesInfoDaoMapper statesInfoDaoMapper;
    @Autowired
    private StatesInfoService statesInfoService;

    //添加订单
    @PostMapping("add")
    public Result<?> add(int serviceId) {
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        TypeDetail byServiceId = statesInfoDaoMapper.getByServiceId(serviceId);
        StatesInfo statesInfo = new StatesInfo();
        statesInfo.setBusinessId(byServiceId.getBusinessId());
        statesInfo.setUserId(userInfo.getUserId());
        statesInfo.setKindId(byServiceId.getKindId());
        statesInfo.setPayTime(LocalDateTime.now());
        statesInfo.setProductStates(0);
        return Result.success(statesInfoService.save(statesInfo));
    }

    //删除订单
    @PostMapping("del")
    public Result<?> del(int id) {
        return Result.success(statesInfoService.removeById(id));
    }

    //查询用户自己的订单
    @PostMapping("list")
    public Result<?> userList(int pageNum, int pageSize, int productStates) {
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        PageHelper.startPage(pageNum, pageSize);
        List<StatesInfo> list = statesInfoService.list(
                new QueryWrapper<StatesInfo>().eq("product_states",productStates).eq("user_id", userInfo.getUserId()));

        PageInfo objectPageInfo = new PageInfo<>(list);
        List<StatesInfoVo> statesInfoVos = new ArrayList<>();
        list.forEach((stateInfo)->{
            StatesInfoVo statesInfoVo = new StatesInfoVo();
            BeanUtils.copyProperties(stateInfo, statesInfoVo);
            statesInfoVo.setBusinessVo(listStatesInfo(stateInfo.getBusinessId(), stateInfo.getKindId()));
        });
        objectPageInfo.setList(statesInfoVos);
        return Result.success(objectPageInfo);
    }

    //查询商家的订单
    @PostMapping("businessList")
    public Result<?> businessList(int pageNum, int pageSize, int productStates) {
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        BusinessInfo business = businessInfoService.getOne(
                new QueryWrapper<BusinessInfo>().eq("user_id", userInfo.getUserId()));
        PageHelper.startPage(pageNum, pageSize);
        List<StatesInfo> list = statesInfoService.list(
                new QueryWrapper<StatesInfo>().eq("product_states",productStates).eq("business_id", business.getBusinessId()));
        PageInfo objectPageInfo = new PageInfo<>(list);
        List<StatesInfoVo> statesInfoVos = new ArrayList<>();
        list.forEach((stateInfo)->{
            StatesInfoVo statesInfoVo = new StatesInfoVo();
            BeanUtils.copyProperties(stateInfo, statesInfoVo);
            statesInfoVo.setBusinessVo(listStatesInfo(stateInfo.getBusinessId(), stateInfo.getKindId()));
        });
        objectPageInfo.setList(statesInfoVos);
        return Result.success(objectPageInfo);
    }



    @Autowired
    private BusinessDaoMapper businessDaoMapper;
    @Autowired
    private TypeDetailDaoMapper typeDetailDaoMapper;
    //查询商家的部分商品
    public BusinessVo listStatesInfo(Integer businessId, Integer kindId) {
        List<BusinessVo> list = null;
        if(businessId != null) {
            list = businessDaoMapper.list(businessId);
            if(kindId !=null) {
                list.get(0).setTypeDetailVos(typeDetailDaoMapper.getByBusinessIdAndKindId(businessId, kindId));
                return list.get(0);
            }
        }
        return new BusinessVo();
    }

}
