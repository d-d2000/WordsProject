package com.rui.yipai.service.serviceImpl;

import com.rui.yipai.dao.UserActivityDaoMapper;
import com.rui.yipai.entity.UserDetail;
import com.rui.yipai.mapper.UserDetailMapper;
import com.rui.yipai.pojo.HomePageInfo;
import com.rui.yipai.service.UserDetailService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Service
public class UserDetailServiceImpl extends ServiceImpl<UserDetailMapper, UserDetail> implements UserDetailService {

    @Autowired
    UserActivityDaoMapper userActivityDaoMapper;

    /**
     * 查询主页信息
     * @param uid
     * @return
     */
    public HomePageInfo UserHomePageInfo(int uid) {
        return userActivityDaoMapper.getHomePageInfo(uid);
    }
}
