package com.rui.yipai.service;

import com.rui.yipai.entity.CollectionInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.rui.yipai.pojo.CollectionActivity;
import com.rui.yipai.pojo.RecommendActivity;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yr
 * @since 2022-10-13
 */
public interface CollectionInfoService extends IService<CollectionInfo> {
    boolean collectionActivity(int activityId,int kind);

    List<CollectionActivity> getCollectionActivity(int getCount);

}
