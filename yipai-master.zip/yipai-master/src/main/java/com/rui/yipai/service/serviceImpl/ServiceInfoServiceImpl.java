package com.rui.yipai.service.serviceImpl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.rui.yipai.entity.ServiceInfo;
import com.rui.yipai.mapper.ServiceInfoMapper;
import com.rui.yipai.service.ServiceInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Service

public class ServiceInfoServiceImpl extends ServiceImpl<ServiceInfoMapper, ServiceInfo> implements ServiceInfoService {
    //批量插入子服务
    @Transactional(rollbackFor = Exception.class)
    public boolean insertService(int detailId, List<ServiceInfo> list) {
        boolean flag = false;
        try {
            for (ServiceInfo serviceInfo : list) {
                serviceInfo.setDetailId(detailId);
            }
            saveBatch(list);
            flag = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }
}
