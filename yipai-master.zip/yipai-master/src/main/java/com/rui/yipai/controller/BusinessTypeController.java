package com.rui.yipai.controller;

import com.rui.yipai.entity.BusinessType;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.pojo.ServiceType;
import com.rui.yipai.service.BusinessInfoService;
import com.rui.yipai.service.BusinessTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@RestController
@RequestMapping("/yipai/businessType")
public class BusinessTypeController {
    @Autowired
    BusinessTypeService businessTypeService;

    @RequestMapping("/addService")
    public Result<?> addService(@RequestBody List<ServiceType> list) {
        boolean flag = businessTypeService.addService(list);
        if(flag) return Result.success("success");
        return Result.error("0","添加失败！");
    }

    @RequestMapping("/myService")
    public Result<?> myService() {
        BusinessType businessType = businessTypeService.myService();
        return Result.success(businessType);
    }
}
