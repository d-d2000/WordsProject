package com.rui.yipai.pojo;

import com.rui.yipai.entity.ServiceInfo;
import com.rui.yipai.entity.TypeDetail;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class ProductInfo {
    private TypeDetail serviceDetail;

    private List<ServiceInfo> sonService;
}
