package com.rui.yipai.pojo;

import com.rui.yipai.entity.ServiceInfo;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class TypeDetailVo {

    private Integer detailId;

    private Integer businessId;

    private Integer kindId;

    private String firstPic;

    private String describes;

    private String sampleList;

    private Integer productStates;

    private List<ServiceInfo> serviceInfos;
}
