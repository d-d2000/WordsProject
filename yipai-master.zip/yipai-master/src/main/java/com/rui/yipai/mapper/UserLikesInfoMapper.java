package com.rui.yipai.mapper;

import com.rui.yipai.entity.UserLikesInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yr
 * @since 2022-10-12
 */
@Mapper
public interface UserLikesInfoMapper extends BaseMapper<UserLikesInfo> {

}
