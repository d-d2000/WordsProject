package com.rui.yipai.dao;

import com.rui.yipai.pojo.TypeDetailVo;
import io.lettuce.core.dynamic.annotation.Param;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface TypeDetailDaoMapper {
    @Select("select t.* from type_detail t "
            +"where t.business_id=#{business_id}")
    @Results({
            @Result(property = "detailId", column = "detail_id"),
            @Result(
                    property = "serviceInfos", column = "detail_id",
                    many = @Many(select = "com.rui.yipai.dao.ServiceInfoDaoMapper.getByDetailId")
            )
    })
    List<TypeDetailVo> getByBusinessId(@Param("business_id") Integer business_id);

    @Select("select t.* from type_detail t " +
            "where t.business_id=#{business_id} and kind_id=#{kind_id}")
    @Results({
            @Result(property = "detailId", column = "detail_id"),
            @Result(
                    property = "serviceInfos", column = "detail_id",
                    many = @Many(select = "com.rui.yipai.dao.ServiceInfoDaoMapper.getByDetailId")
            )
    })
    List<TypeDetailVo> getByBusinessIdAndKindId(@Param("business_id") Integer business_id, @Param("kind_id") Integer kind_id);

}
