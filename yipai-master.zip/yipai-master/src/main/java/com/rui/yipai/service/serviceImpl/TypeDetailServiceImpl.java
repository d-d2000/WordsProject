package com.rui.yipai.service.serviceImpl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.rui.yipai.entity.BusinessInfo;
import com.rui.yipai.entity.ServiceInfo;
import com.rui.yipai.entity.TypeDetail;
import com.rui.yipai.entity.UserInfo;
import com.rui.yipai.mapper.BusinessInfoMapper;
import com.rui.yipai.mapper.TypeDetailMapper;
import com.rui.yipai.service.TypeDetailService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.rui.yipai.utils.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Service
public class TypeDetailServiceImpl extends ServiceImpl<TypeDetailMapper, TypeDetail> implements TypeDetailService {

    @Autowired
    RedisTemplate redisTemplate;

    @Autowired
    BusinessInfoMapper businessInfoMapper;

    @Autowired
    TypeDetailMapper typeDetailMapper;

    @Autowired
    ServiceInfoServiceImpl serviceInfoService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean addServiceInfo(TypeDetail typeDetail, List<ServiceInfo> serviceInfoList)  {
        boolean flag = false;

        //获取businessId
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        int userId = userInfo.getUserId();
        QueryWrapper<BusinessInfo> businessInfoQueryWrapper = new QueryWrapper<>();
        businessInfoQueryWrapper.select("business_id").eq("user_id",userId);
        BusinessInfo businessInfo = businessInfoMapper.selectOne(businessInfoQueryWrapper);

        int businessId = businessInfo.getBusinessId();
        //插入基本信息
        typeDetail.setBusinessId(businessId);

        try{
            typeDetailMapper.insert(typeDetail);
            System.out.println(typeDetail.toString());
            System.out.println(typeDetail.getDetailId());
            serviceInfoService.insertService(typeDetail.getDetailId(),serviceInfoList);
            flag = true;
        } catch (Exception e) {
            e.printStackTrace();
            //回滚
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }

        return flag;
    }
}
