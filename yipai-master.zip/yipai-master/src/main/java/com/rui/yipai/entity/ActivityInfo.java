package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Getter
@Setter
@TableName("activity_info")
@ApiModel(value = "ActivityInfo对象", description = "")
public class ActivityInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("同动态默认的id")
    @TableId(value = "activity_id", type = IdType.AUTO)
    private Integer activityId;

    @ApiModelProperty("用户对应的默认id")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty("商家对应的id")
    @TableField("business_id")
    private Integer businessId;

    @ApiModelProperty("动态的封面，默认为第一张")
    @TableField("cover_pic")
    private String coverPic;

    @ApiModelProperty("动态的可见范围，默认为公开，0：公开，1：私密，2：粉丝可见")
    @TableField("activity_grant")
    private Integer activityGrant;

    @ApiModelProperty("用户动态的文本，可写可不写")
    @TableField("activity_txt")
    private String activityTxt;

    @ApiModelProperty("用户动态的ip位置，可写可不写")
    @TableField("activity_address")
    private String activityAddress;

    @ApiModelProperty("点赞数量")
    @TableField("activity_likes_numbers")
    private Integer activityLikesNumbers;

    @ApiModelProperty("评论数量")
    @TableField("activity_comments_numbers")
    private Integer activityCommentsNumbers;

    @ApiModelProperty("转发数量")
    @TableField("activity_forwarding_numbers")
    private Integer activityForwardingNumbers;

    @ApiModelProperty("当前多有动态图片的链接拼接")
    @TableField("activity_pic_list")
    private String activityPicList;

    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @ApiModelProperty("发送动态的时间")
    @TableField("activity_time")
    private LocalDateTime activityTime;

    @TableField(fill = FieldFill.DEFAULT)
    private boolean collectionState;

    @TableField(fill = FieldFill.DEFAULT)
    private int collectionNum;
}
