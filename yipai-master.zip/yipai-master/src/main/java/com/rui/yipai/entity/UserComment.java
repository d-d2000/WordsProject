package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Getter
@Setter
@TableName("user_comment")
@ApiModel(value = "UserComment对象", description = "")
public class UserComment implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("评论对应的id")
    @TableId(value = "comment_id", type = IdType.AUTO)
    private Integer commentId;

    @ApiModelProperty("对应动态的id")
    @TableField("activity_id")
    private Integer activityId;

    @ApiModelProperty("评论人的id")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty("评论的内容")
    @TableField("comment_msg")
    private String commentMsg;

    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @ApiModelProperty("评论的时间")
    @TableField("create_date")
    private LocalDateTime createDate;

    @ApiModelProperty("评论的赞个数")
    @TableField("zan_count")
    private Integer zanCount;

    @ApiModelProperty("赞过这条评论的人的id")
    @TableField("zan_id")
    private String zanId;


}
