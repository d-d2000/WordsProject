package com.rui.yipai.mapper;

import com.rui.yipai.entity.BusinessType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yr
 * @since 2023-01-12
 */
@Mapper
public interface BusinessTypeMapper extends BaseMapper<BusinessType> {

}
