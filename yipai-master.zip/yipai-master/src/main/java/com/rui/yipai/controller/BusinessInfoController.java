package com.rui.yipai.controller;

import com.rui.yipai.dao.BusinessDaoMapper;
import com.rui.yipai.dao.TypeDetailDaoMapper;
import com.rui.yipai.entity.BusinessInfo;
import com.rui.yipai.pojo.BusinessVo;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.service.BusinessInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-10-20
 */
@RestController
@RequestMapping("/yipai/businessInfo")
public class BusinessInfoController {

    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    BusinessInfoService businessInfoService;

    @PostMapping("/applyBeBoss")
    public Result<?> applyBeBoss(@RequestBody BusinessInfo businessInfo) {
        boolean flag = businessInfoService.applyBoss(businessInfo);
        if(flag) return Result.success("200");
        else return Result.error("0000","申请失败！请稍后再试");
    }

    @GetMapping("/selectState")
    public Result<?> selectState() {
        int flag = businessInfoService.businessState();
        if(flag < 0) return Result.success("200");
        else return Result.success(flag);
    }

    @Autowired
    private BusinessDaoMapper businessDaoMapper;
    @Autowired
    private TypeDetailDaoMapper typeDetailDaoMapper;
    //查询商家的部分或所有商品
    @PostMapping("/list")
    public Result<?> getServiceInfo(Integer businessId, Integer kindId) {
        List<BusinessVo> list = null;
        if(businessId != null) {
            list = businessDaoMapper.list(businessId);
            if(kindId !=null) {
                list.get(0).setTypeDetailVos(typeDetailDaoMapper.getByBusinessIdAndKindId(businessId, kindId));
            } else {
                list.get(0).setTypeDetailVos(typeDetailDaoMapper.getByBusinessId(businessId));
            }
        } else {
            list = businessDaoMapper.listAll();
            if(kindId!=null) {
                list.forEach(businessVo -> {
                    businessVo.setTypeDetailVos(typeDetailDaoMapper.getByBusinessIdAndKindId(businessVo.getBusinessId(), kindId));
                });
            } else {
                list.forEach(businessVo -> {
                    businessVo.setTypeDetailVos(typeDetailDaoMapper.getByBusinessId(businessVo.getBusinessId()));
                });
            }
        }
        return Result.success(list);
    }

}
