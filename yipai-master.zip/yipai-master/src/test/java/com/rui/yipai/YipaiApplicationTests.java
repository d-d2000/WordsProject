package com.rui.yipai;

import com.rui.yipai.dao.UserActivityDaoMapper;
import com.rui.yipai.pojo.CollectionActivity;
import com.rui.yipai.pojo.RecommendActivity;
import com.rui.yipai.utils.RedisUtil;
import com.rui.yipai.utils.VerifyUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.ScanOptions;

import java.util.Collection;
import java.util.List;
import java.util.Map;

@SpringBootTest
class YipaiApplicationTests {

  @Autowired
  RedisUtil redisUtil;

  @Autowired
  UserActivityDaoMapper userActivityDaoMapper;

  @Test
  void contextLoads() {
//    redisUtil.zAdd("article:"+1,2+"",System.currentTimeMillis());
//    redisUtil.hPut("test","1","111");
//    redisUtil.hPut("test","2","222");
//    redisUtil.hPut("test","3","333");
//
//    String test = (String) redisUtil.hGet("test", "1");
//    test = "111111111111111111";
//    redisUtil.hPut("test","1",test);
//    Cursor<Map.Entry<Object, Object>> cursor = redisUtil.hScan("test", ScanOptions.NONE);
//    while (cursor.hasNext()) {
//      Map.Entry<Object, Object> v = cursor.next();
//      System.out.println(v.getKey()+":"+v.getValue());
//    }

    List<CollectionActivity> collectionActivity = userActivityDaoMapper.getCollectionActivity("35,36");
    System.out.println(collectionActivity);
  }
}