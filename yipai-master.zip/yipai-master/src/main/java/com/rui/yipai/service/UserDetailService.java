package com.rui.yipai.service;

import com.rui.yipai.entity.UserDetail;
import com.baomidou.mybatisplus.extension.service.IService;
import com.rui.yipai.pojo.HomePageInfo;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
public interface UserDetailService extends IService<UserDetail> {
    HomePageInfo UserHomePageInfo(int uid);
}
