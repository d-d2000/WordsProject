package com.rui.yipai.service;

import com.rui.yipai.entity.MsgInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
public interface MsgInfoService extends IService<MsgInfo> {

}
