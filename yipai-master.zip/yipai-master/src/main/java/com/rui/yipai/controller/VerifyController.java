package com.rui.yipai.controller;

import com.rui.yipai.entity.UserInfo;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.service.UserService;
import com.rui.yipai.utils.UserRequest;
import io.lettuce.core.dynamic.annotation.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/getVerify")
public class VerifyController {

  @Autowired
  UserService userService;

  @Autowired
  RedisTemplate redisTemplate;

  /**
   * 使用验证码登录时查询手机详情
   * @param userTel
   * @return
   */
  @GetMapping("/loginVerify")
  public String loginVerify(String userTel) {
    //数据库查询登陆者的信息
    if(userService.isTel(userTel)) {
      return "success";
    }
    else return "手机号尚未注册，请注册后再登陆！";
  }

  /**
   * 注册时查询受是否已经注册
   * @param userTel
   * @return
   */
  @RequestMapping("/RegisterVerify")
  public String RegisterVerify(String userTel) {
    if(userService.isTel(userTel)) {
      return "手机号已被注册，请更换手机号重试！";
    }
    else return "success";
  }


  /**
   * 查询redis内的信息与发送短信的手机号做对比，已检测是否是本账号
   * @param userTel
   * @return
   */
  @GetMapping("/checkTel")
  public Result<?> updateUerPassword(String userTel) {

    UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
    //如果电话号码不匹配，驳回更改密码
    if(!userInfo.getUserTel().equals(userTel)) {
      return Result.error("0000","手机号不匹配！");
    } else {
      return Result.success("success");
    }
  }
}
