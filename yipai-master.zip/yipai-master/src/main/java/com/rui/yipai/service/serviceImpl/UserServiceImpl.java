package com.rui.yipai.service.serviceImpl;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.common.utils.BinaryUtil;
import com.aliyun.oss.model.MatchMode;
import com.aliyun.oss.model.PolicyConditions;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.rui.yipai.dao.UserInfoDaoMapper;
import com.rui.yipai.entity.*;
import com.rui.yipai.mapper.*;
import com.rui.yipai.service.UserService;
import com.rui.yipai.utils.MD5Util;
import com.rui.yipai.utils.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserInfoMapper userInfoMapper;

    @Autowired
    UserInfoDaoMapper userInfoDaoMapper;

    @Autowired
    UserDetailMapper userDetailMapper;

    @Autowired
    FunsInfoMapper funsInfoMapper;

    @Autowired
    CollectionInfoMapper collectionInfoMapper;

    @Autowired
    UserLikesInfoMapper userLikesInfoMapper;

    @Autowired
    RedisUtil redisUtil;
    /**
     * 登陆信息的查询
     * @param userInfo
     * @return
     */
    @Override
    public UserInfo userLogin(UserInfo userInfo) {
        //将密码二次加密后与数据库中的密码进行对比
        userInfo.setUserPass(MD5Util.backToDb(userInfo.getUserPass()));
        return userInfoDaoMapper.getLoginUserInfo(userInfo);
    }

    /**
     * Redis查询用户的验证码并验证
     * @param userTel
     * @param sms
     * @return
     */
    @Override
    public UserInfo verifyLogin(String userTel, String sms) {
        //从Redis获取到验证码
        if(sms.equals(redisUtil.get(userTel))) return userInfoDaoMapper.getUserInfo(userTel);
        else return null;
    }

    @Override
    public boolean isRegisterSMS(String userTel, String sms) {
        if(sms.equals(redisUtil.get(userTel))) return true;
        else return false;
    }

    @Override
    public UserDetail getActivityNum(UserInfo userInfo) {
        QueryWrapper<UserDetail> wrapper = new QueryWrapper<>();
        wrapper.select("user_activity_num")
                .eq("user_id",userInfo.getUserId());
        UserDetail detail = userDetailMapper.selectOne(wrapper);
        if(detail != null) return detail;
        return null;
    }




    /**
     * 新用户的注册
     * @param userInfo
     * @return
     */
    @Override
    public boolean userRegister(UserInfo userInfo) {
        //防止用户恶意注册，插入前在查询一次是否存在用户
        if(userInfoDaoMapper.isRegister(userInfo.getUserTel()) != null) return false;

        //先对用户的密码进行二次md5加密
        userInfo.setUserPass(MD5Util.backToDb(userInfo.getUserPass()));

        //将数据存入数据库
        int flag = userInfoMapper.insert(userInfo); //判断插入数据是否成功
        //插入成功后更新一次详细表、粉丝表、收藏表、点赞表的数据
        if(flag == 1) {
            //获取新注册的用户id
            QueryWrapper<UserInfo> wrapper = new QueryWrapper<>();
            wrapper.select("user_id")
                    .eq("user_tel",userInfo.getUserTel());
            UserInfo userInfo1 = userInfoMapper.selectOne(wrapper);

            //更新详细表
            UserDetail userDetail = new UserDetail();
            userDetail.setUserId(userInfo1.getUserId());
            userDetailMapper.insert(userDetail);

            //更新粉丝表
            FunsInfo funsInfo = new FunsInfo();
            funsInfo.setUserId(userInfo1.getUserId());
            funsInfoMapper.insert(funsInfo);

            //更新点赞表
            UserLikesInfo userLikesInfo = new UserLikesInfo();
            userLikesInfo.setUserId(userInfo1.getUserId());
            userLikesInfoMapper.insert(userLikesInfo);

            //更新收藏表
            CollectionInfo collectionInfo = new CollectionInfo();
            collectionInfo.setUserId(userInfo1.getUserId());
            collectionInfoMapper.insert(collectionInfo);

            return true;
        }
        else return false;
    }

    /**
     * 为前端直传oss生成签名
     * @return
     */
    public Map<String, String> sendPolicy() {
        System.err.println("被请求了！");
        String accessId = "LTAI5tJ8qFX9cbHGc7WZQQzx"; // 请填写您的AccessKeyId。
        String accessKey = "RCkcHoHM7nARxdS90awKiAqxNh3VXU"; // 请填写您的AccessKeySecret。
        String endpoint = "oss-cn-beijing.aliyuncs.com"; // 请填写您的 endpoint。
        String bucket = "duan-daun"; // 请填写您的 bucketname 。
        String host = "https://" + bucket + "." + endpoint; // host的格式为 BucketName.endpoint

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String date = simpleDateFormat.format(new Date());

        String dir = "前端直传测试/" + date + "/"; // 用户上传文件时指定的前缀。

        // 创建OSSClient实例。
        OSS ossClient = new OSSClientBuilder().build(endpoint, accessId, accessKey);
        try {
            long expireTime = 30;
            long expireEndTime = System.currentTimeMillis() + expireTime * 1000;
            Date expiration = new Date(expireEndTime);
            // PostObject请求最大可支持的文件大小为5 GB，即CONTENT_LENGTH_RANGE为5*1024*1024*1024。
            PolicyConditions policyConds = new PolicyConditions();
            policyConds.addConditionItem(PolicyConditions.COND_CONTENT_LENGTH_RANGE, 0, 1048576000);
            policyConds.addConditionItem(MatchMode.StartWith, PolicyConditions.COND_KEY, dir);


            String postPolicy = ossClient.generatePostPolicy(expiration, policyConds);
            byte[] binaryData = postPolicy.getBytes("utf-8");
            String encodedPolicy = BinaryUtil.toBase64String(binaryData);
            String postSignature = ossClient.calculatePostSignature(postPolicy);

            Map<String, String> respMap = new LinkedHashMap<String, String>();
            //阿里云oss前端直传必须参数
            respMap.put("accessid", accessId);
            respMap.put("policy", encodedPolicy);
            respMap.put("signature", postSignature);
            respMap.put("dir", dir);
            respMap.put("host", host);
            respMap.put("expire", String.valueOf(expireEndTime / 1000));
            // respMap.put("expire", formatISO8601Date(expiration));
            return respMap;
        } catch (Exception e) {
            // Assert.fail(e.getMessage());
            System.out.println(e.getMessage());
        } finally {
            ossClient.shutdown();
        }
        return null;
    }

    /**
     * 获取短信验证码前查询手机号的状态
     */
    @Override
    public boolean isTel(String userTel) {
        System.out.println("查询结果为："+userInfoDaoMapper.isRegister(userTel));
        //先查询手机号是否已经注册
        if(userInfoDaoMapper.isRegister(userTel) == null) return false;
        else return true;
    }
}
