package com.rui.yipai.pojo;

import com.rui.yipai.entity.ActivityInfo;
import com.rui.yipai.entity.UserInfo;
import lombok.Data;

import java.util.List;

@Data
public class HomePageInfo {
    private Integer userId;
    //粉丝数
    private Integer userFansNum;
    //关注数
    private Integer userAttentionNum;
    //获赞数
    private Integer userLikedNum;
    //个人简介
    private String userBriefIntroduction;
    //个人背景图片
    private String userBgk;
    //用户动态
    private List<ActivityInfo> userActivityInfo;
    //用户
    private UserInfo userInfo;
}
