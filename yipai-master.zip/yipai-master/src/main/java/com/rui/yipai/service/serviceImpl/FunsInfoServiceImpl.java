package com.rui.yipai.service.serviceImpl;

import com.rui.yipai.entity.FunsInfo;
import com.rui.yipai.mapper.FunsInfoMapper;
import com.rui.yipai.service.FunsInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Service
public class FunsInfoServiceImpl extends ServiceImpl<FunsInfoMapper, FunsInfo> implements FunsInfoService {

}
