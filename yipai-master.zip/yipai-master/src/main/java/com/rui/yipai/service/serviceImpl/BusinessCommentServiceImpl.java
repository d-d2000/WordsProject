package com.rui.yipai.service.serviceImpl;

import com.rui.yipai.entity.BusinessComment;
import com.rui.yipai.mapper.BusinessCommentMapper;
import com.rui.yipai.service.BusinessCommentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Service
public class BusinessCommentServiceImpl extends ServiceImpl<BusinessCommentMapper, BusinessComment> implements BusinessCommentService {

}
