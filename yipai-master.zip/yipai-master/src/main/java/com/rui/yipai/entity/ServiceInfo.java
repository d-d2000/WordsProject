package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Getter
@Setter
@TableName("service_info")
@ApiModel(value = "ServiceInfo对象", description = "")
public class ServiceInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("子服务默认id")
    @TableId("service_id")
    private Integer serviceId;

    @ApiModelProperty("具体业务的id")
    @TableField("detail_id")
    private Integer detailId;

    @ApiModelProperty("子服务的编号")
    @TableField("son_service_id")
    private Integer sonServiceId;

    @ApiModelProperty("子服务的名字")
    @TableField("son_service_name")
    private String sonServiceName;

    @ApiModelProperty("子服务的图片")
    @TableField("son_service_pic")
    private String sonServicePic;

    @ApiModelProperty("子服务的库存")
    @TableField("son_service_stock")
    private Integer sonServiceStock;

    @ApiModelProperty("子服务的价格")
    @TableField("son_service_price")
    private Integer sonServicePrice;

    @ApiModelProperty("预约时间")
    @TableField("service_date_id")
    private String serviceDateId;


}
