package com.rui.yipai.controller;


import com.rui.yipai.entity.UserInfo;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.service.UserService;
import com.rui.yipai.utils.JwtUtil;
import com.rui.yipai.utils.RedisUtil;
import com.rui.yipai.utils.UserRequest;
import io.lettuce.core.dynamic.annotation.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.util.Map;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService userService;

    @Autowired
    RedisTemplate redisTemplate;

    @Autowired
    RedisUtil redisUtil;

    /**
     * 使用密码登录
     * @param userInfo
     * @return
     */
    @RequestMapping("/login")
    public Result<?> login(@RequestBody UserInfo userInfo) {
        UserInfo user = userService.userLogin(userInfo);
        if(user != null) {
            user.setFansNums(
                    userService
                            .getActivityNum(user)
                            .getUserActivityNum());
            String token = JwtUtil.sign(user.getUserId());
            redisTemplate.opsForValue().set(token,user, Duration.ofMinutes(60*24*7L));
            return Result.success(token);
        } else {
            return Result.error("1","手机号或密码错误");
        }
    }

    /**
     * 验证码登录
     * @param userTel
     * @param sms
     * @return
     */
    @RequestMapping("/loginByVerify")
    public Result<?> loginByVerify( String userTel,String sms) {
        UserInfo user = userService.verifyLogin(userTel,sms);
        user.setFansNums(
                userService
                        .getActivityNum(user)
                        .getUserActivityNum());
        if(user != null) {
            String token = JwtUtil.sign(user.getUserId());
            redisTemplate.opsForValue().set(token,user, Duration.ofMinutes(60*24*7L));
            return Result.success(token);
        } else {
            return Result.error("2","验证码错误");
        }
    }

    /**
     * 注册验证码
     * @param userTel
     * @param sms
     * @return
     */
    @RequestMapping("/isRegisterVerify")
    public String isRegisterVerify( String userTel, String sms) {
        if(userService.isRegisterSMS(userTel,sms)) return "success";
        else return "验证码有误！";
    }

    /**
     * 注册
     * @param user
     * @return
     */
    @RequestMapping("/register")
    public String register(@RequestBody UserInfo user) {
        if(userService.userRegister(user)) return "success";
        else return "error";
    }

    /**
     * 用户退出登录时，删除redis内的token
     * @return
     */
    @GetMapping("deleteToken")
    public Result<?> deleteToken() {
        boolean res = redisTemplate.delete(UserRequest.getCurrentToken());
        if(res) return Result.success("success");
        else return Result.error("5","请稍后再试");
    }

    /**
     * 为前端直传oss下发签名
     * @return
     */
    @RequestMapping("/getPolicy")
    public Map<String,String> getPolicy() {
        return userService.sendPolicy();
    }

}
