package com.rui.yipai.mapper;

import com.rui.yipai.entity.MsgInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Mapper
public interface MsgInfoMapper extends BaseMapper<MsgInfo> {

}
