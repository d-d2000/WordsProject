package com.rui.yipai.dao;

import com.rui.yipai.entity.ServiceInfo;
import io.lettuce.core.dynamic.annotation.Param;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ServiceInfoDaoMapper {
    @Select("select * from service_info where detail_id=#{detail_id}")
    List<ServiceInfo> getByDetailId(@Param("detail_id") Integer detail_id);
}
