package com.rui.yipai.service.serviceImpl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.rui.yipai.entity.UserInfo;
import com.rui.yipai.mapper.UserInfoMapper;
import com.rui.yipai.service.UserInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.rui.yipai.utils.MD5Util;
import com.rui.yipai.utils.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Service
public class UserInfoServiceImpl extends ServiceImpl<UserInfoMapper, UserInfo> implements UserInfoService {

    @Autowired
    UserInfoMapper userInfoMapper;

    @Autowired
    RedisTemplate redisTemplate;

    /**
     * 更新用户头像
     * @param userInfo
     * @return
     */
    @Override
    public boolean updateHead(UserInfo userInfo) {
        UpdateWrapper<UserInfo> wrapper = new UpdateWrapper<>();
        wrapper.eq("user_id",userInfo.getUserId())
                .set("user_face",userInfo.getUserFace());
        int flag = userInfoMapper.update(null,wrapper);
        if(flag > 0) return true;
        else return false;
    }

    @Override
    public boolean updatePassword(String password1) {
        //数据库查询二次加密密码
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        QueryWrapper<UserInfo> queryWrapper = new QueryWrapper();
        queryWrapper.select("user_pass").eq("user_tel",userInfo.getUserTel());
        String password = userInfoMapper.selectOne(queryWrapper).getUserPass();

        //与用户输入的密码进行对比
        if(MD5Util.backToDb(password1).equals(password)) return false;//两次密码一致，不允许修改

        //更新数据库密码
        UpdateWrapper<UserInfo> updateWrapper = new UpdateWrapper();
        updateWrapper.eq("user_tel",userInfo.getUserTel()).set("user_pass",MD5Util.backToDb(password1));
        int flag = userInfoMapper.update(null,updateWrapper);
        if(flag > 0) {
            return true;
        } else {
            return false;
        }
    }
}
