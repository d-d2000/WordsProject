package com.rui.yipai.mapper;

import com.rui.yipai.entity.BusinessInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yr
 * @since 2022-10-20
 */
@Mapper
public interface BusinessInfoMapper extends BaseMapper<BusinessInfo> {

}
