package com.rui.yipai.dao;

import com.rui.yipai.entity.BusinessType;
import io.lettuce.core.dynamic.annotation.Param;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface BusinessTypeDaoMapper {
    @Select("select b.* from business_type b where b.business_id=#{business_id}")
    BusinessType getByBusinessId(@Param("business_id") int business_id);
}
