package com.rui.yipai.service;



import com.rui.yipai.entity.UserDetail;
import com.rui.yipai.entity.UserInfo;

import java.util.Map;

public interface UserService {

  UserInfo userLogin(UserInfo userInfo);

  boolean userRegister(UserInfo userInfo);

  Map<String,String> sendPolicy();

  boolean isTel(String userTel);

  UserInfo verifyLogin(String userTel,String sms);

  boolean isRegisterSMS(String userTel,String sms);

  UserDetail getActivityNum(UserInfo userInfo);

}
