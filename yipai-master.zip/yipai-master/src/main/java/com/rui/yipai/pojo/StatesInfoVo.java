package com.rui.yipai.pojo;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
public class StatesInfoVo {

    private Integer statesId;

    private Integer businessId;

    private Integer kindId;

    private Integer userId;

    private Integer productStates;

    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime payTime;

    private BusinessVo businessVo;
}
