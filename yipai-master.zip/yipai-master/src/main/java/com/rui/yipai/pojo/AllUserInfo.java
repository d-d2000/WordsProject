package com.rui.yipai.pojo;

import com.rui.yipai.entity.UserDetail;
import com.rui.yipai.entity.UserInfo;
import lombok.Data;

@Data
public class AllUserInfo {
    private UserInfo userInfo;
    private UserDetail userDetail;
}
