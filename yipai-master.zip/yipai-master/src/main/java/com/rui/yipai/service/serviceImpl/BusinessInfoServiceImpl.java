package com.rui.yipai.service.serviceImpl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.rui.yipai.entity.BusinessInfo;
import com.rui.yipai.entity.UserInfo;
import com.rui.yipai.mapper.BusinessInfoMapper;
import com.rui.yipai.service.BusinessInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.rui.yipai.utils.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-10-20
 */
@Service
public class BusinessInfoServiceImpl extends ServiceImpl<BusinessInfoMapper, BusinessInfo> implements BusinessInfoService {

    @Autowired
    BusinessInfoMapper businessInfoMapper;

    @Autowired
    RedisTemplate redisTemplate;

    /**
     * 申请成为商家
     * @param businessInfo
     * @return
     */
    @Override
    public boolean applyBoss(BusinessInfo businessInfo) {
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        int userId = userInfo.getUserId();
        businessInfo.setUserId(userId);
        int flag = businessInfoMapper.insert(businessInfo);
        if(flag > 0) return true;
        else return false;
    }

    /**
     * 查询店铺状态
     * @return
     */
    @Override
    public int businessState() {
        UserInfo userInfo = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
        int userId = userInfo.getUserId();
        QueryWrapper<BusinessInfo> businessInfoQueryWrapper = new QueryWrapper<>();
        businessInfoQueryWrapper.select("state").eq("user_id",userId);
        BusinessInfo businessInfo = businessInfoMapper.selectOne(businessInfoQueryWrapper);
        if(businessInfo != null) {
            return businessInfo.getState();
        } else return -1;
    }
}
