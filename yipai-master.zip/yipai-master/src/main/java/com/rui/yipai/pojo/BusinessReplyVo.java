package com.rui.yipai.pojo;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.rui.yipai.entity.UserInfo;
import lombok.Data;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@ToString
public class BusinessReplyVo {
    private Integer businessReplyId;

    private Integer businessCommentId;

    private Integer fromUserId;

    private Integer toUserId;

    private String replyMsg;

    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    private LocalDateTime createDate;

    private UserInfo fromUserInfo;

    private UserInfo toUserInfo;
}
