package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Getter
@Setter
@TableName("msg_info")
@ApiModel(value = "MsgInfo对象", description = "")
public class MsgInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("消息表默认的id")
    @TableId(value = "msg_id", type = IdType.AUTO)
    private Integer msgId;

    @ApiModelProperty("发送者的id")
    @TableField("post_id")
    private Integer postId;

    @ApiModelProperty("接受者的id")
    @TableField("receive_id")
    private Integer receiveId;

    @ApiModelProperty("信息")
    @TableField("msg")
    private String msg;

    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @ApiModelProperty("发送时间")
    @TableField("post_time")
    private LocalDateTime postTime;


}
