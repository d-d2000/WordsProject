package com.rui.yipai.service.serviceImpl;

import com.rui.yipai.entity.UserLikesInfo;
import com.rui.yipai.mapper.UserLikesInfoMapper;
import com.rui.yipai.service.UserLikesInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yr
 * @since 2022-10-12
 */
@Service
public class UserLikesInfoServiceImpl extends ServiceImpl<UserLikesInfoMapper, UserLikesInfo> implements UserLikesInfoService {

}
