package com.rui.yipai.pojo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ServiceType {
    private String name;
    private String type;
    private int typeCode;
    private String kindPic;
}
