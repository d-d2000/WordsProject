package com.rui.yipai.controller;

import com.rui.yipai.entity.UserInfo;
import com.rui.yipai.pojo.Result;
import com.rui.yipai.service.UserInfoService;
import com.rui.yipai.service.UserService;
import com.rui.yipai.utils.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@RestController
@RequestMapping("/yipai/userInfo")
public class UserInfoController {

    @Autowired
    RedisTemplate redisTemplate;

    @Autowired
    UserInfoService userInfoService;

    /**
     * 通过请求头中的token得到user信息
     * @return UserInfo
     */
    @GetMapping("/allInfo")
    public Result<?> allInfo() {

        return Result.success((UserInfo)redisTemplate.opsForValue().get(UserRequest.getCurrentToken()));
    }

    /**
     * 换头像，修改该数据库后，从请求头中拿到token并重新设置user信息
     * @param userInfo
     * @return
     */
    @RequestMapping("/updateHeadPic")
    public Result<?> updateHeadPic(@RequestBody UserInfo userInfo) {
        boolean res = userInfoService.updateHead(userInfo);
        //数据库更新成功后更新redis
        if(res) {
            UserInfo updateUser = (UserInfo) redisTemplate.opsForValue().get(UserRequest.getCurrentToken());
            //替换头像
            updateUser.setUserFace(userInfo.getUserFace());
            //覆盖先前的用户信息
            redisTemplate.opsForValue().set(UserRequest.getCurrentToken(),updateUser,Duration.ofMinutes(60*24*7L));
            return Result.success("success");
        }
        else return Result.error("3","上传头像失败！");
    }


    @GetMapping("/updatePassword")
    public Result<?> updatePassword(String password1) {
        boolean flag = userInfoService.updatePassword(password1);
        if(flag) {
            return Result.success("200");
        } else {
            return Result.error("0000","修改失败或更新密码与近期相同");
        }
    }
}
