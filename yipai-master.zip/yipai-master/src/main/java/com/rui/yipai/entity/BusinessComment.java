package com.rui.yipai.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
@Getter
@Setter
@TableName("business_comment")
@ApiModel(value = "BusinessComment对象", description = "")
public class BusinessComment implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("商家动态评论的id")
    @TableId(value = "business_comment_id", type = IdType.AUTO)
    private Integer businessCommentId;

    @ApiModelProperty("对应商家动态的id")
    @TableField("detail_id")
    private Integer detailId;

    @ApiModelProperty("评论人的id")
    @TableField("user_id")
    private Integer userId;

    @ApiModelProperty("评论的内容")
    @TableField("comment_msg")
    private String commentMsg;

    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @ApiModelProperty("日期")
    @TableField("create_date")
    private LocalDateTime createDate;

    @ApiModelProperty("赞数")
    @TableField("zan_count")
    private Integer zanCount;

    @ApiModelProperty("赞的人的id拼接")
    @TableField("zan_id")
    private String zanId;


}
