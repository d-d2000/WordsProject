package com.rui.yipai.service;

import com.rui.yipai.entity.UserInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yr
 * @since 2022-05-17
 */
public interface UserInfoService extends IService<UserInfo> {

    boolean updateHead(UserInfo userInfo);

    boolean updatePassword(String password1);
}
